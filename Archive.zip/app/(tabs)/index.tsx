import { SafeAreaView } from 'react-native-safe-area-context';
import { ScrollView, Text, View, Pressable } from 'react-native';
import { Link } from 'expo-router';

export default function HomeScreen() {
  return (
    <SafeAreaView className="flex-1 bg-slate-50">
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 24 }}
      >
        {/* Header */}
        <View className="mt-2">
          <Text className="text-3xl font-extrabold text-slate-900">UniBite</Text>
          <Text className="mt-1 text-sm text-slate-500">
            Smart recipes from your real fridge. Built for busy students.
          </Text>
        </View>

        {/* Highlight card */}
        <View className="mt-6 bg-white rounded-2xl shadow-sm px-5 py-4">
          <Text className="text-sm font-semibold text-emerald-500">
            Tonight&apos;s game plan
          </Text>
          <Text className="mt-2 text-lg font-semibold text-slate-900">
            See what you can cook in minutes.
          </Text>
          <Text className="mt-1 text-sm text-slate-500">
            Add what&apos;s in your fridge, then let UniBite ask the AI chef for ideas.
          </Text>

          <View className="mt-4 flex-row space-x-3">
            <Link href="/(tabs)/fridge" asChild>
              <Pressable className="flex-1 bg-emerald-500 rounded-2xl py-3 items-center justify-center shadow-md">
                <Text className="text-white text-sm font-semibold">
                  Open my fridge
                </Text>
              </Pressable>
            </Link>
            <Link href="/(tabs)/recipes" asChild>
              <Pressable className="flex-1 bg-emerald-50 rounded-2xl py-3 items-center justify-center border border-emerald-200">
                <Text className="text-emerald-600 text-sm font-semibold">
                  What&apos;s for dinner?
                </Text>
              </Pressable>
            </Link>
          </View>
        </View>

        {/* Quick tips / secondary cards */}
        <View className="mt-6 space-y-3">
          <View className="bg-white rounded-2xl shadow-sm px-4 py-3">
            <Text className="text-sm font-semibold text-slate-800">
              1. Fill your fridge
            </Text>
            <Text className="mt-1 text-xs text-slate-500">
              Add anything you have on hand: leftovers, snacks, basics. UniBite will
              only suggest recipes using what you actually own.
            </Text>
          </View>

          <View className="bg-white rounded-2xl shadow-sm px-4 py-3">
            <Text className="text-sm font-semibold text-slate-800">
              2. Let AI plan the meal
            </Text>
            <Text className="mt-1 text-xs text-slate-500">
              Hit &quot;What&apos;s for dinner?&quot; on the Recipes tab to get a
              simple, budget‑friendly meal idea.
            </Text>
          </View>

          <View className="bg-white rounded-2xl shadow-sm px-4 py-3">
            <Text className="text-sm font-semibold text-slate-800">
              3. Save your favourites
            </Text>
            <Text className="mt-1 text-xs text-slate-500">
              Loved something? Save it on the Recipes tab so you can find it again
              before your next grocery run.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}