import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { auth } from '@/services/firebase';
import {
  addInventoryItem,
  deleteInventoryItem,
  subscribeToInventory,
} from '@/services/inventory';
import type { IngredientCategory, InventoryItem } from '@/utils/types';

const CATEGORIES: { label: string; value: IngredientCategory }[] = [
  { label: 'Veg', value: 'veg' },
  { label: 'Meat', value: 'meat' },
  { label: 'Dairy', value: 'dairy' },
  { label: 'Grain', value: 'grain' },
  { label: 'Snack', value: 'snack' },
  { label: 'Other', value: 'other' },
];

const DEFAULT_PANTRY = ['Salt', 'Oil', 'Pepper'];

export default function FridgeScreen() {
  const user = auth.currentUser;
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [ingredientName, setIngredientName] = useState('');
  const [category, setCategory] = useState<IngredientCategory>('other');

  const [pantryStaples, setPantryStaples] = useState<Record<string, boolean>>(
    Object.fromEntries(DEFAULT_PANTRY.map((p) => [p, true])),
  );

  useEffect(() => {
    if (!user?.uid) {
      setLoading(false);
      return;
    }

    const unsubscribe = subscribeToInventory(
      user.uid,
      (nextItems) => {
        setItems(nextItems);
        setLoading(false);
      },
      (err) => {
        setError(err.message);
        setLoading(false);
      },
    );

    return unsubscribe;
  }, [user?.uid]);

  const handleAdd = async () => {
    if (!user?.uid) {
      Alert.alert('Not logged in', 'Please log in again to manage your fridge.');
      return;
    }

    if (!ingredientName.trim()) {
      Alert.alert('Missing name', 'Please enter an ingredient name.');
      return;
    }

    try {
      setAdding(true);
      await addInventoryItem(user.uid, ingredientName.trim(), category);
      setIngredientName('');
      setCategory('other');
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to add ingredient.');
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteInventoryItem(id);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to delete ingredient.');
    }
  };

  const togglePantryItem = (name: string) => {
    setPantryStaples((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  if (!user) {
    return (
      <SafeAreaView className="flex-1 bg-slate-50">
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-2xl font-bold text-slate-800 mb-2">My Fridge</Text>
          <Text className="text-sm text-slate-500 text-center">
            Please log in to manage your fridge.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-slate-50">
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View className="flex-1 px-4 pb-4">
          {/* Header */}
          <View className="mt-2">
            <Text className="text-3xl font-extrabold text-slate-900">My Fridge</Text>
            <Text className="mt-1 text-sm text-slate-500">
              Add what you&apos;ve got and UniBite will handle the rest.
            </Text>
          </View>

          {/* Add item row */}
          <View className="mt-4 flex-row items-center space-x-3">
            <View className="flex-1 bg-white rounded-2xl px-4 py-3 shadow-sm border border-slate-100">
              <TextInput
                placeholder="Add an ingredient"
                placeholderTextColor="#9ca3af"
                value={ingredientName}
                onChangeText={setIngredientName}
                className="text-base text-slate-800"
              />
            </View>
            <Pressable
              onPress={handleAdd}
              disabled={adding}
              className="w-12 h-12 rounded-2xl bg-emerald-500 items-center justify-center shadow-md"
            >
              <Text className="text-white text-2xl font-bold">+</Text>
            </Pressable>
          </View>

          {/* Category chips */}
          <View className="mt-3 flex-row flex-wrap gap-2">
            {CATEGORIES.map((c) => {
              const active = category === c.value;
              return (
                <Pressable
                  key={c.value}
                  onPress={() => setCategory(c.value)}
                  className={`px-3 py-1.5 rounded-full border shadow-sm flex-row items-center ${
                    active
                      ? 'bg-emerald-50 border-emerald-500'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <Text
                    className={`text-xs font-medium ${
                      active ? 'text-emerald-600' : 'text-slate-600'
                    }`}
                  >
                    {c.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* Inventory list */}
          <View className="mt-5 flex-1">
            <Text className="text-sm font-semibold text-slate-700 mb-2">
              Current ingredients
            </Text>

            {loading ? (
              <ActivityIndicator />
            ) : error ? (
              <Text className="text-sm text-rose-500">{error}</Text>
            ) : items.length === 0 ? (
              <Text className="text-sm text-slate-400">
                Your fridge is looking bare. Add your first ingredient above.
              </Text>
            ) : (
              <FlatList
                data={items}
                keyExtractor={(item) => item.id}
                contentContainerStyle={{ paddingBottom: 12 }}
                renderItem={({ item }) => (
                  <View className="bg-white rounded-2xl px-4 py-3 shadow-sm border border-slate-100 mb-2 flex-row items-center justify-between">
                    <View>
                      <Text className="text-sm font-semibold text-slate-900">
                        {item.ingredientName}
                      </Text>
                      <Text className="text-[11px] text-slate-500 capitalize mt-1">
                        {item.category}
                      </Text>
                    </View>
                    <Pressable
                      onPress={() => handleDelete(item.id)}
                      className="px-3 py-1 rounded-full bg-rose-50 border border-rose-200"
                    >
                      <Text className="text-[11px] font-semibold text-rose-500">
                        Remove
                      </Text>
                    </Pressable>
                  </View>
                )}
              />
            )}
          </View>

          {/* Pantry Staples card */}
          <View className="mt-2 bg-white rounded-2xl px-4 py-3 shadow-sm border border-slate-100">
            <Text className="text-sm font-semibold text-slate-800">
              Pantry staples
            </Text>
            <Text className="text-xs text-slate-500 mt-1">
              These basics are always assumed to be available for recipes.
            </Text>

            <View className="mt-2 space-y-2">
              {DEFAULT_PANTRY.map((name) => (
                <View
                  key={name}
                  className="flex-row items-center justify-between py-1.5"
                >
                  <Text className="text-sm text-slate-700">{name}</Text>
                  <Switch
                    value={pantryStaples[name]}
                    onValueChange={() => togglePantryItem(name)}
                    trackColor={{ false: '#e5e7eb', true: '#6ee7b7' }}
                    thumbColor={pantryStaples[name] ? '#10b981' : '#ffffff'}
                  />
                </View>
              ))}
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}